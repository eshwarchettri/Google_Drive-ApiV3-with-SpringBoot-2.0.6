/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cloudelemets.assignment.util;

/**
 *
 * @author Eesha chettri
 */


public class View {

	public static void downloadStatus(String status) {
		System.out.println(status);
		
	}

	public static void uploadStatus(String status) {
		System.out.println(status);
		
	}

}

