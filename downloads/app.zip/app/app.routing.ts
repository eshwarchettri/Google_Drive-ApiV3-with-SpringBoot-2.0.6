import {ModuleWithProviders} from '@angular/core';
import {Routes,RouterModule} from '@angular/router';
import {LoginComponent} from './components/login/login.component';
import {AddNewClientComponent} from './components/add-new-client/add-new-client.component';
import {ViewClientsComponent} from './components/view-clients/view-clients.component';
import {ClientHomeComponent} from './components/client-home/client-home.component';
import { AdminDashbaordComponent } from "./components/admin-dashbaord/admin-dashbaord.component";
const appRoutes: Routes=[
{
path:'',
redirectTo:'/login',
pathMatch:'full'
},
{
path:'login',
component:LoginComponent
},
{
    path:'addClient',
    component:AddNewClientComponent
},
{
    path:'clientList',
    component:ViewClientsComponent
},
{
    path:'home',
    component:ClientHomeComponent
},
{
    path:'admin',
    component:AdminDashbaordComponent
}
];

export const routing:ModuleWithProviders=RouterModule.forRoot(appRoutes);
