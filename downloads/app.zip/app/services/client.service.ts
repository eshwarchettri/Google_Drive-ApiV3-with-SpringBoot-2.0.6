import { Injectable } from '@angular/core';
import {Client} from '../models/client';
import {Http, Headers} from '@angular/http';
import {AppConst} from '../constants/app-const';
import {HeaderMappingDetails} from '../models/mapheader';
import { Observable, Subject, pipe } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ClientService {
  private serverPath: string = AppConst.serverPath;

  constructor(private http:Http) { }
  newUser(clientname: string, email:string,password:string,subject:string,username:string) {
  	const url = this.serverPath+'/user/newUser';
  	const userInfo = {
  		'username' : username,
  		'email' : email,
                'password': password,
                'subject': subject,
                'clientname':clientname
  	}
  	const tokenHeader = new Headers({
  		'Content-Type' : 'application/json',
  		'x-auth-token' : localStorage.getItem('xAuthToken')
  	});

  	return this.http.post(url, JSON.stringify(userInfo), {headers : tokenHeader});
  }
gleConsole(){
    const url = this.serverPath+'/user/gleConsole';
  	const tokenHeader = new Headers({
  		'Content-Type' : 'application/json',
  		'x-auth-token' : localStorage.getItem('xAuthToken')
  	});

  	return this.http.get(url,{headers : tokenHeader});
}
goToUrl(url: string) {
// return window.open(url, 'url', 'menubar=no,status=no,location=no,toolbar=no,scrollbars=yes,resizable=no');
    // return window.open(url,'_blank' );
    // window.close();
}
closeWindow(){
	const url = this.serverPath + '/user/closeWindow';
	const tokenHeader = new Headers({
	'Content-Type' : 'application/json',
	'x-auth-token' : localStorage.getItem('xAuthToken')
			});
		return 	window.opener.this.http.post(url, {headers : tokenHeader});
	}


getHeaders(){
    console.log('');
		const url = this.serverPath + '/user/getHeaders';
  	const tokenHeader = new Headers({
		'Content-Type' : 'application/json',
  		'x-auth-token' : localStorage.getItem('xAuthToken')
  	});

  	return this.http.get(url	, {headers : tokenHeader});
    
}
saveHeaders(mapHeaders) {
    const url = this.serverPath + '/user/saveHeaders';
const tokenHeader = new Headers({
'Content-Type' : 'application/json',
'x-auth-token' : localStorage.getItem('xAuthToken')
  	});
  	return this.http.post(url, mapHeaders, {headers : tokenHeader});
}
}
