import { TestBed, inject } from '@angular/core/testing';

import { RemoveClientService } from './remove-client.service';

describe('RemoveClientService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [RemoveClientService]
    });
  });

  it('should be created', inject([RemoveClientService], (service: RemoveClientService) => {
    expect(service).toBeTruthy();
  }));
});
