import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {AppConst} from '../constants/app-const';
import { Observable, Subject, pipe } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class AdmindashboardserviceService {
  private serverPath: string = AppConst.serverPath;
  constructor(private http:HttpClient) { }

  getDataForCharts(){
    let url = this.serverPath+'/user/chartData';
    let tokenHeader = new HttpHeaders({
  		'Content-Type' : 'application/json',
  		'x-auth-token' : localStorage.getItem('xAuthToken')
    });
    // console.log(url);
    return this.http.get(url, {headers : tokenHeader});

  }
}
