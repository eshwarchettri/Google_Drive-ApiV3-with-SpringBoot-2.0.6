import { Injectable } from '@angular/core';
import {Http, Headers} from '@angular/http';
import {AppConst} from '../constants/app-const'

@Injectable({
  providedIn: 'root'
})
export class ViewclientService {
  private serverPath: string = AppConst.serverPath;

  constructor(private http:Http) { }
  
  getClients() {    
    let url = this.serverPath+'/user/getClients';
  	let tokenHeader = new Headers({
  		'Content-Type' : 'application/json',
  		'x-auth-token' : localStorage.getItem('xAuthToken')
  	});
  	return this.http.get(url,{headers : tokenHeader});    
}
}
