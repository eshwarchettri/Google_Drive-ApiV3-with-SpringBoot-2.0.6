import { Injectable } from '@angular/core';
import {Http, Headers} from '@angular/http';
//import {Client} from '../models/client';
import {AppConst} from '../constants/app-const'



@Injectable({
  providedIn: 'root'
})
export class RemoveClientService {
      private serverPath: string = AppConst.serverPath;


  constructor(private http:Http) { }
   sendClient(clientId: number) {
  	let url = this.serverPath+'/user/disableClient';
    
    let headers = new Headers ({
      'Content-Type': 'application/json',
      'x-auth-token' : localStorage.getItem('xAuthToken')
    });

    return this.http.post(url, clientId, {headers: headers});
  }
  
  }
