import { TestBed, inject } from '@angular/core/testing';

import { ViewclientService } from './viewclient.service';

describe('ViewclientService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ViewclientService]
    });
  });

  it('should be created', inject([ViewclientService], (service: ViewclientService) => {
    expect(service).toBeTruthy();
  }));
});
