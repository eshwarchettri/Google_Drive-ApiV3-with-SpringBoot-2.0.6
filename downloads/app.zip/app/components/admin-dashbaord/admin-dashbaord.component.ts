import { Component, OnInit, ElementRef, ViewChild} from '@angular/core';
import {AdmindashboardserviceService} from '../../services/admindashboardservice.service';
import { Chart } from 'chart.js';
import {LoginService} from '../../services/login.service';


@Component({
  selector: 'app-admin-dashbaord',
  templateUrl: './admin-dashbaord.component.html',
  styleUrls: ['./admin-dashbaord.component.css']
})
export class AdminDashbaordComponent implements OnInit {
  @ViewChild('orderCanvas') orderCanvas: ElementRef;
  @ViewChild('revenueCanvas') revenueCanvas: ElementRef;
  @ViewChild('impressionCanvas') impressionCanvas: ElementRef;
  @ViewChild('clickCanvas') clickCanvas: ElementRef;
revchart: any = [];
orderchart: any = [];
impressionchart: any = [];
clickchart: any = [];
label = [];
labels = ['date1', 'date2', 'date3'];
private loggedIn = true;
  constructor(private adminDashboardService: AdmindashboardserviceService, private loginService: LoginService) { }
getDataForCharts() {
  this.adminDashboardService.getDataForCharts().subscribe(
    (res: any) => {
    // Data for Orders Chart
     const orderHtmlRef = this.orderCanvas.nativeElement.getContext('2d');
     this.orderchart = this.getCharts(orderHtmlRef, 'Orders', res.orders, this.labels);
     // Data for Revenue Chart
     const revHtmlRef = this.revenueCanvas.nativeElement.getContext('2d');
     this.revchart = this.getRevChart(revHtmlRef, res.revenue);
     // Data for Impressions Chart
     const impHtmlRef=this.impressionCanvas.nativeElement.getContext('2d');
     this.impressionchart = this.getCharts(impHtmlRef, 'Impressions', res.impressions, this.labels);
     // Data for Clicks Chart
     const clickHtmlRef=this.clickCanvas.nativeElement.getContext('2d');
     this.clickchart = this.getCharts(clickHtmlRef, 'Clicks', res.clicks, this.labels);

    }, error => {
      console.log(error);
    }
  );
}
  ngOnInit() {
       this.getDataForCharts();
       this.loginService.checkSession().subscribe(
        res => {
          this.loggedIn = true;
        },
        error => {
          this.loggedIn = false;
        }
      );
  }
 getCharts(htmlRef, label, data, labels) { 
  return new Chart(htmlRef, {
      type: 'line',
      data: {
          labels: labels,
          datasets: [{
                  tension: 0,
                  backgroundColor: "rgba(216, 188, 246, 0.7)",
                  borderWidth: 2,
                  pointBorderColor: "#5c06f1",
                  pointRadius: 4,
                  borderJoinStyle: 'miter',
                  data: data,
                  label: label,
                  borderColor: "#5c06f1",
                  fill: true,
                  borderCapStyle: 'butt'


              }
          ]
      },
      options: {
          maintainAspectRatio: true,
          scales: {
              xAxes: [{
                      gridLines: {
                          display: true,
                          lineWidth: 1
//                            drawOnChartArea: true
                      }
                  }],
              yAxes: [{
                      gridLines: {
                          display: true,
                          lineWidth: 1
//                            drawOnChartArea: true
                      }
                  }]
          },
          tooltips: {

              mode: 'x',
              callbacks: {
                  labelColor: function (tooltipItem, chart) {
                      return {
                          borderColor: 'rgb(255, 0, 0)',
                          backgroundColor: '#8e5ea2'
                      }
                  },
                  labelTextColor: function (tooltipItem, chart) {
                      return '#3e95cd';
                  }
              }
          }, legend: {
//                            labels: {
              // This more specific font property overrides the global property
              display: false
//                            }
          }, emptyOverlay: {// enabled by default
              fillStyle: 'rgba(74, 100, 100, 0.04)', // Change the color of the overlay to red with a 40% alpha
              fontColor: 'rgba(0, 0, 0, 1)', // Change the text color to white
              fontStrokeWidth: 0        // Hide the stroke around the text
          }

      }
  });
}


getRevChart(htmlRef, revenueData) {
  Chart.defaults.global.legend.labels.usePointStyle = true;  
  const revData = {
      labels: ["date1", "date2", "date3"],
      datasets: [{
              backgroundColor: [
                  "#327FED",
                  "#FFDF7F",
                  "#818181"
                  // "#3BD6B6",
                  // "#FEA4B6",
                  // "#FF0E00",
                  // "#9953DF"
              ],
              data: revenueData,
              borderColor: 'black',
              borderWidth: 0.5
          }],
  };
  return  new Chart(htmlRef, {
      type: 'doughnut',
      data: revData,
      options: {
          legend: {
              display: true,
              position: 'bottom',
              fullWidth: true

          },
          emptyOverlay: {// enabled by default
              fillStyle: 'rgba(74, 100, 100, 0.04)', // Change the color of the overlay to red with a 40% alpha
              fontColor: 'rgba(0, 0, 0, 1)', // Change the text color to white
              fontStrokeWidth: 0        // Hide the stroke around the text
          },
          maintainAspectRatio: true
              }
  });
}

}
