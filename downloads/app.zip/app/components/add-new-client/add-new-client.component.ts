import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {LoginService} from '../../services/login.service';
import {ClientService} from '../../services/client.service';
import {Client} from '../../models/client';
import {HeaderMappingDetails} from '../../models/mapheader';
import {FormControl} from '@angular/forms';
import {Observable} from 'rxjs';
import {map, startWith} from 'rxjs/operators';



@Component({
  selector: 'app-add-new-client',
  templateUrl: './add-new-client.component.html',
  styleUrls: ['./add-new-client.component.css']
})
export class AddNewClientComponent implements OnInit { 
       
     myControl =new FormControl();
  private   tdDisabled = false;

         private mapper:string[];
  private emptyMap:string[];
  private filteredMap:string[];
  filteredOptions: Observable<string[]>;
         private headerMap: HeaderMappingDetails=new HeaderMappingDetails();
        private clientName:string;
        private username:string;
        private emailID:string;
        private password:string;
        private subject:string;
        private ismapped =false;
        private usernameExists:boolean;
        private loggedIn = false;
        private showMapper =false;
  private emailExists:boolean;
private newClient:Client=new Client();
private clientAdded:boolean;
  constructor(private clientService:ClientService,private router: Router,private loginService:LoginService) {
    
    }


  onNewAccount() {     
  	this.usernameExists = false;
  	this.emailExists = false;

  	this.clientService.newUser(this.clientName, this.emailID,this.password,this.subject,this.username).subscribe(
  		res => {
                      const resSTR = JSON.stringify(res);
                       const resJSON = JSON.parse(resSTR);
                       const data = this.clientService.goToUrl(resJSON._body);
                       console.log(data);
                        // const foo= this.clientService.closeWindow().sub;
                        // console.log(foo);
                        this.clientService.closeWindow().subscribe(
                          ( res: any) => {
                            console.log(res);
                          }
                        );
                        window.close();
                        // window.opener.refreshAfterAccess();
                        this.clientAdded = true;
                        this.ismapped = true;
  		},
  		error => {
  			console.log(error.text());
                        this.clientAdded = false;
  			let errorMessage = error.text();
  			if(errorMessage==='usernameExists') this.usernameExists=true;
  			if(errorMessage==="emailExists") this.emailExists=true;
  		}
  	);
  }
  refreshAfterAccess(){
    console.log('""');
    this.clientService.closeWindow().subscribe();
  }
  headerMapper(){
      this.clientService.getHeaders().subscribe(
      res=>{
         console.log(res);
          const resSTR = JSON.stringify(res);
          const resJSON = JSON.parse(resSTR);

          this.mapper = JSON.parse(resJSON._body);
          console.log(this.mapper);
          this.showMapper=true;
         this.ismapped=false;
        this.emptyMap=this.mapper;
      }
      );
      
  }
saveHeaders(){
    this.clientService.saveHeaders(this.headerMap).subscribe(
    res=>{
        console.log(res);       
    },error=>{
        console.log(error);
    }
    );     
}
 ngOnInit() {
     this.showMapper =false;

  	this.loginService.checkSession().subscribe(
  		res => {
  			this.loggedIn = true;
  		},
  		error => {
  			this.loggedIn = false;
  		}
  	);

  }

filterStates(val: string) {
    return val ? this._filter(this.mapper, val) : this.mapper;
  }
  
  private _filter(map: string[], val: string) {
    const filterValue = val.toLowerCase();
    return map.filter(state => state.toLowerCase().startsWith(filterValue));
  }
}