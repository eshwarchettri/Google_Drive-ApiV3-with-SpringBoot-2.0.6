import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';
import {LoginService} from '../../services/login.service';
import {ViewclientService} from '../../services/viewclient.service';
import {RemoveClientService} from '../../services/remove-client.service';
import {HeaderMappingDetails} from '../../models/mapheader';
import {Client} from '../../models/client';
import {MatDialog,MatDialogRef} from '@angular/material';
import {DialogComponentComponent} from '../dialog-component/dialog-component.component';




@Component({
  selector: 'app-view-clients',
  templateUrl: './view-clients.component.html',
  styleUrls: ['./view-clients.component.css']
})
export class ViewClientsComponent implements OnInit {
private clientList:Client[];
private checked:boolean;
private allChecked:boolean;
private selectedClient:Client;
private isDiasble:number;
private removeClientList:Client[]=new Array();
private loggedIn = false;
  constructor(private viewclientService:ViewclientService,private router:Router,public dialog:MatDialog,private removeClientService:RemoveClientService) { }

  ngOnInit() {
      this.getClients();
      this.loggedIn = true;
  }
  getClients() {
      this.loggedIn = true;
    this.viewclientService.getClients().subscribe(
      res => {
//        console.log(res.json());
        this.clientList=res.json();
        console.log(this.clientList);
      }, 
      error => {
        console.log(error);
      }
      );
  }
  openDialog(client:Client) {
    let dialogRef = this.dialog.open(DialogComponentComponent, {
  height: '200px',
  width: '300px',
});
    dialogRef.afterClosed().subscribe(
      result => {
        console.log(result);
        if(result=="yes") {
          this.removeClientService.sendClient(client.clientID).subscribe(
            res => {
                this.loggedIn = true;
              console.log(res);
              this.getClients();
              
            }, 
            err => {
              console.log(err);
            }
            );
        }
      }
      );
  }
  
  updateSelected(checked:boolean){
      if(checked){
          this.allChecked=true;
          this.removeClientList=this.clientList.slice();
      }else {
      this.allChecked=false;
      this.removeClientList=[];
    }
      
  }
  updateRemoveClientList(checked:boolean,client:Client){
      if(checked) {
      this.removeClientList.push(client);
    } else {
      this.removeClientList.splice(this.removeClientList.indexOf(client), 1);
    }
  }

}
//@Component({
//  selector: 'dialog-result-example-dialog',
//  templateUrl: './dialog-result-example-dialog.html'
//})
//export class DialogResultExampleDialog {
//  constructor(public dialogRef: MatDialogRef<DialogResultExampleDialog>) {}
//  
//  
//}