import { Component, OnInit, Output, EventEmitter} from '@angular/core';
import {LoginService} from '../../services/login.service';
import { Router} from '@angular/router';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
     @Output() messageEvent = new EventEmitter<boolean>();

private credential={'username':'','password':''};
private loggedIn=false;
private admin:boolean;;

  constructor(private loginService:LoginService,private router:Router) {}
onSubmit(){
this.loginService.sendCredentials(this.credential.username,this.credential.password).subscribe(
res=>{
//console.log(res);
localStorage.setItem("xAuthToken",res.json().token);
//console.log(localStorage.getItem("xAuthToken"));
this.loggedIn=true;
location.reload();
var clientrole=this.credential.username;
if(clientrole.toLowerCase() != "admin"){
    localStorage.setItem("currentLogin",clientrole.toLowerCase()); 
    this.router.navigate(['/home']);   
}else{
  localStorage.setItem("currentLogin","admin");  
  console.log("admin"); 
  this.router.navigate(['/admin']);
}
},
error=>{
console.log(error);
}

);
}

  ngOnInit() {
this.loginService.checkSession().subscribe(
res=>{
this.loggedIn=true;
},error=>{
this.loggedIn=false;
}
  );
  }

}
