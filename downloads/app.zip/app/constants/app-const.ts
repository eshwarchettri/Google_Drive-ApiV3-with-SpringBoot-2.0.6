export class AppConst {
	public static serverPath = 'http://localhost:8081';
}