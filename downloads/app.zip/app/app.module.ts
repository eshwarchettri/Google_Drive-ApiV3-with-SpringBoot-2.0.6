import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import {
MatInputModule,
MatFormFieldModule,
MatButtonModule,
MatMenuModule,
MatToolbarModule,
MatIconModule,
MatCardModule,
MatSelectModule,
MatListModule,
MatSidenavModule,
MatGridListModule,
MatCheckboxModule,
MatTabsModule,
MatDialogModule,
MatAutocompleteModule
} from '@angular/material';
import { AppComponent } from './app.component';
import 'hammerjs';
import { NavBarComponent } from './components/nav-bar/nav-bar.component';
import { LoginComponent } from './components/login/login.component';
import { LoginService } from './services/login.service';
import { ClientService } from './services/client.service';
import { ViewclientService } from './services/viewclient.service';
import { RemoveClientService } from './services/remove-client.service';
import {AdmindashboardserviceService} from './services/admindashboardservice.service'



import {HttpModule} from '@angular/http';
import {HttpClientModule} from '@angular/common/http';
import {routing} from './app.routing';
import { AddNewClientComponent } from './components/add-new-client/add-new-client.component';
import { ViewClientsComponent } from './components/view-clients/view-clients.component';
import { ClientHomeComponent } from './components/client-home/client-home.component';
import { DialogComponentComponent } from './components/dialog-component/dialog-component.component';
import { AdminDashbaordComponent } from "./components/admin-dashbaord/admin-dashbaord.component";

import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';


const materialModules = [
MatInputModule,
MatFormFieldModule,
MatButtonModule,
MatMenuModule,
MatToolbarModule,
MatIconModule,
MatCardModule,
MatSelectModule,
MatListModule,
MatSidenavModule,
MatGridListModule,
MatCheckboxModule,
MatTabsModule,
MatDialogModule,
MatAutocompleteModule
]


@NgModule({
  declarations: [
    AppComponent,
    NavBarComponent,
    LoginComponent,
    AddNewClientComponent,
    ViewClientsComponent,
    ClientHomeComponent,
    DialogComponentComponent,
    AdminDashbaordComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
materialModules,
HttpModule,
HttpClientModule,
routing,
FormsModule,
NgxMatSelectSearchModule,
ReactiveFormsModule,
    MatAutocompleteModule
  ],  exports: [materialModules],

  providers: [LoginService,ClientService,ViewclientService,AdmindashboardserviceService],

  bootstrap: [AppComponent],
  entryComponents: [AddNewClientComponent,DialogComponentComponent]
})
export class AppModule { }