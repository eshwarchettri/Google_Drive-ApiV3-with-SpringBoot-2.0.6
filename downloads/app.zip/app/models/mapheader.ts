export class HeaderMappingDetails {
  public impressions: string;
   public clicks: string;
   public revenue: string;
   public orders: string;
   public cpo: string;
   public cpc: string;
   public rbyc: string;
   public aov: string;
   public ctr: string;
   public session: string;
   public roas: string;
   public cvr: string;
   public geo_location: string;
   public country: string;
   public date: string;
   public clientId: number;
   public emailId: string;
   public budget: string;
   public newSessionPercentage: string;
   public cost:string;
}

