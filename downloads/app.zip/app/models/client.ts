export class Client {
  public clientID: number;
public clientName: string;
public password: string;
public emailID: string;
public enabled: boolean;
public subject:string;
}

