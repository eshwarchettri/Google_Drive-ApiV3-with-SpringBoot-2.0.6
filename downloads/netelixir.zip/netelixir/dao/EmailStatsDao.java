/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.netelixir.dao;

import com.netelixir.model.EmailReportStats;
import com.netelixir.repository.EmailReportsRepository;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import javax.persistence.EntityManagerFactory;
import org.hibernate.HibernateException;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.NativeQuery;
import org.hibernate.query.QueryProducer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author netelixir
 */
//@Repository
@Transactional
@Component
public class EmailStatsDao implements EmailReportsRepository {

    private static final Logger LOG = LoggerFactory.getLogger(EmailStatsDao.class);

    @Autowired
    EmailReportsRepository emailReportsRepository;

    @Autowired
    private EntityManagerFactory entityManagerFactory;

    @Override
    public List<EmailReportStats> findByclientId(int clientId) {
        return emailReportsRepository.findByclientId(clientId);
    }

    @Override
    public <S extends EmailReportStats> S save(S s) {
        return emailReportsRepository.save(s);

    }

    @Override
    public <S extends EmailReportStats> Iterable<S> saveAll(Iterable<S> itrbl) {
        return emailReportsRepository.saveAll(itrbl);
    }

    @Override
    public Optional<EmailReportStats> findById(Integer id) {
        return emailReportsRepository.findById(id);

    }

    @Override
    public boolean existsById(Integer id) {
        return emailReportsRepository.existsById(id);

    }

    @Override
    public Iterable<EmailReportStats> findAll() {
        return emailReportsRepository.findAll();

    }

    @Override
    public Iterable<EmailReportStats> findAllById(Iterable<Integer> itrbl) {
        return emailReportsRepository.findAllById(itrbl);
    }

    @Override
    public long count() {
        return emailReportsRepository.count();
    }

    @Override
    public void deleteById(Integer id) {

        emailReportsRepository.deleteById(id);
    }

    @Override
    public void delete(EmailReportStats t) {
        emailReportsRepository.delete(t);

    }

    @Override
    public void deleteAll(Iterable<? extends EmailReportStats> itrbl) {
        emailReportsRepository.deleteAll();

    }

    @Override
    public void deleteAll() {
        emailReportsRepository.deleteAll();

    }

    public List<EmailReportStats> getLastSevenDaysData(String sqlQuery) {
        List<EmailReportStats> emailReportStatses = new ArrayList<>();
        Session session = entityManagerFactory.unwrap(SessionFactory.class).openSession();
        try {
//            String hql = "select * from ne_email_stats where client_id=" + clientId + " and date between '" + fromDate + "' and '" + toDate+"'";
            NativeQuery query = session.createNativeQuery(sqlQuery);
            query.addEntity(EmailReportStats.class);
            emailReportStatses = query.list();
        } catch (HibernateException exception) {
            LOG.debug("Exception occured due to " + exception);
        } finally {
            if (session != null) {
                session.close();
            }
        }
        return emailReportStatses;
    }

}
