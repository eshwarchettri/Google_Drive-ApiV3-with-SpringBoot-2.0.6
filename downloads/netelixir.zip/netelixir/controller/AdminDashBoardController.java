/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.netelixir.controller;

import com.netelixir.model.EmailReportStats;
import com.netelixir.service.AdminDashBoardService;
import com.netelixir.util.CommonFunction;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author netelixir
 */
@RestController
@RequestMapping("/user")
public class AdminDashBoardController {
    @Autowired 
    AdminDashBoardService adminDashBoardService;
    CommonFunction commonFunction=new CommonFunction();
    @GetMapping(value="/chartData")
    public Map<String,List<String>> getChartData(){
    String dates[]=commonFunction.getDates(7);
    Map<String,List<String>> emailReportsStats=adminDashBoardService.getLastSevenDaysData(dates[0],dates[1],13);
    return emailReportsStats;
    }
}
