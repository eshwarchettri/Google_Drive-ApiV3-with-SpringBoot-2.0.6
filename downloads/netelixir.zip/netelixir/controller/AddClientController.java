/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.netelixir.controller;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.api.client.auth.oauth2.AuthorizationCodeRequestUrl;
import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.auth.oauth2.TokenResponse;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeFlow;
import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.services.gmail.GmailScopes;
import com.google.api.services.gmail.model.ListMessagesResponse;
import com.netelixir.config.SecurityUtility;
import com.netelixir.domain.User;
import com.netelixir.domain.security.Role;
import com.netelixir.domain.security.UserRole;
import com.netelixir.model.ClientHomePage;
import com.netelixir.service.ClientInfoService;
import com.netelixir.model.ClientInformation;
import com.netelixir.model.HeaderMappingDetails;
import com.netelixir.service.GmailService;
import com.netelixir.service.UserService;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.view.RedirectView;
import redis.clients.jedis.Jedis;
import com.google.gson.Gson;
import com.netelixir.service.HeaderMappingService;
import java.lang.reflect.Array;
import java.util.Arrays;
import org.springframework.web.bind.annotation.PostMapping;

/**
 *
 * @author netelixir
 */
@RestController
@Configuration
@PropertySource(value = {"classpath:application.properties"})
@RequestMapping("/user")
public class AddClientController {

    private static final Log LOGGER = LogFactory.getLog(AddClientController.class);
    @Value("${gmail.client.clientId}")
    private String CLIENT_ID;

    @Value("${gmail.client.redirectUri}")
    private String REDIRECT_URI;

    @Value("${gmail.client.clientSecret}")
    private String CLIENT_SECRET;

    GoogleClientSecrets clientSecrets;
    GoogleAuthorizationCodeFlow flow;
    Credential credential;
    private static HttpTransport httpTransport;
    private static final JsonFactory JSON_FACTORY = JacksonFactory.getDefaultInstance();

    @Autowired
    private UserService userService;

    @Autowired
    GmailService gmailService;

    @Autowired
    ClientInfoService clientInformationService;

    Jedis jedis = new Jedis("127.0.0.1", 6379);

    @RequestMapping(value = "/newUser", method = RequestMethod.POST)
    public ResponseEntity addNewClient(HttpServletRequest request, @RequestBody HashMap<String, String> mapper, HttpSession session, HttpServletResponse response) {
        Jedis jedis = new Jedis("127.0.0.1", 6379);
        String username = mapper.get("username");
        String password = mapper.get("password");
        String email = mapper.get("email");
        String clientName = mapper.get("clientname");
        boolean isValidEmail = isValid(email);
        String subject = mapper.get("subject");
        if (userService.findByUsername(username) != null) {
            return new ResponseEntity("usernameExists", HttpStatus.BAD_REQUEST);
        }

        if (userService.findByEmail(email) != null || !isValidEmail) {
            return new ResponseEntity("emailExists", HttpStatus.BAD_REQUEST);
        }
        User user = new User();
        user.setUsername(username);
        user.setEmail(email);
        user.setPassword(SecurityUtility.passwordEncoder().encode(password));
        
        Role role = new Role();
        role.setRoleId(1);
        role.setName("ROLE_USER");
        Set<UserRole> userRoles = new HashSet<>();
        userRoles.add(new UserRole(user, role));
        User newUser = userService.createUser(user, userRoles);
        RedirectView redirectView = new RedirectView();
        if (userService.findByUsername(username) != null) {
            try {

                session.setAttribute("clientId", newUser.getId());

                session.setAttribute("clientEmailId", newUser.getEmail());
                ClientHomePage ci = new ClientHomePage();
                ci.setEmailid(email);
                ci.setSubject(subject);
                ci.setClientName(clientName);
                ci.setPassword(password);

                ClientInformation clientInformation = clientInformationService.saveNewClientInfo(ci, Integer.parseInt(newUser.getId().toString()));
                jedis.set("emailClientId", String.valueOf(clientInformation.getClientID()));
                redirectView = googleConnectionStatus();
//                response.sendRedirect(redirectView.getUrl());
//                return null;
                LOGGER.info(redirectView.getUrl());
            } catch (Exception ex) {
                Logger.getLogger(AddClientController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        return new ResponseEntity(redirectView.getUrl(), HttpStatus.OK);
    }

    public RedirectView googleConnectionStatus() throws Exception {
        return new RedirectView(authorize());
    }

    @RequestMapping(value = "/getHeaders", method = RequestMethod.GET)
    public List<String> getCSVHeaders() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        Jedis jedis = new Jedis("127.0.0.1", 6379);
        String[] headerColumns = mapper.readValue(jedis.get("headerColumns"), new TypeReference<String[]>() {
        });
        List<String> wordList = Arrays.asList(headerColumns);

        return wordList;
    }

    private String authorize() throws Exception {
        AuthorizationCodeRequestUrl authorizationUrl;
        if (flow == null) {
            GoogleClientSecrets.Details web = new GoogleClientSecrets.Details();
            web.setClientId(CLIENT_ID);
            web.setClientSecret(CLIENT_SECRET);
            clientSecrets = new GoogleClientSecrets().setWeb(web);
            httpTransport = GoogleNetHttpTransport.newTrustedTransport();
            flow = new GoogleAuthorizationCodeFlow.Builder(httpTransport, JSON_FACTORY, clientSecrets,
                    Collections.singleton(GmailScopes.GMAIL_READONLY)).build();
        }
        authorizationUrl = flow.newAuthorizationUrl().setRedirectUri(REDIRECT_URI).setAccessType("offline").setApprovalPrompt("force");

        System.out.println("gamil authorizationUrl ->" + authorizationUrl);
        return authorizationUrl.build();
    }

    @RequestMapping("/getClients")
    public List<ClientInformation> getAllClients() {
        return clientInformationService.findAll();
    }
    
    
    @PostMapping(value="/disableClient")
	public ResponseEntity remove(@RequestBody String id) throws IOException {
		clientInformationService.disableClient(Integer.parseInt(id));
				
		return new ResponseEntity("Remove Success!", HttpStatus.OK);
	}
    @PostMapping(value="/closeWindow")
	public ResponseEntity closeWindow() throws IOException {					
		return new ResponseEntity("Remove Success!", HttpStatus.OK);
	}

    @RequestMapping(value = "login/gmailCallback", method = RequestMethod.GET, params = "code")
    public String oauth2Callback(@RequestParam(value = "code") String code, HttpSession session, Model model) {
//        Map<String, ArrayList<String>> headerColumns = new LinkedHashMap<>();
        String[] headerColumns = new String[15];
        try {
            Jedis jedis = new Jedis("127.0.0.1", 6379);
            TokenResponse response = flow.newTokenRequest(code).setRedirectUri(REDIRECT_URI).execute();
            credential = flow.createAndStoreCredential(response, "userID");
            Integer clientId = Integer.parseInt(jedis.get("emailClientId"));
            clientInformationService.saveTokens(response, clientId);
            ListMessagesResponse MsgResponse = gmailService.getGmailMessage(credential, clientId);
            headerColumns = gmailService.readMessgeAndProcess(session, MsgResponse, false, clientId);
            ObjectMapper mapper = new ObjectMapper();
            jedis.set("headerColumns", mapper.writeValueAsString(headerColumns));

        } catch (IOException e) {

            LOGGER.debug("error is due to: " + e);

        }
        session.setAttribute("headerColumns", headerColumns);
        model.addAttribute("headerColumns", headerColumns);
        model.addAttribute("clientId", session.getAttribute("clientId"));
        model.addAttribute("emailId", session.getAttribute("clientEmailId"));
        model.addAttribute("mapHeaders", new HeaderMappingDetails());
        return "successfull";
    }

    public boolean isValid(String emailId) {
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."
                + "[a-zA-Z0-9_+&*-]+)*@"
                + "(?:[a-zA-Z0-9-]+\\.)+[a-z"
                + "A-Z]{2,7}$";
        Pattern pat = Pattern.compile(emailRegex);
        if (emailId == null) {
            return false;
        }
        return pat.matcher(emailId).matches();
    }
}
