/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.netelixir.controller;

import com.netelixir.model.HeaderMappingDetails;
import com.netelixir.service.HeaderMappingService;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import redis.clients.jedis.Jedis;

/**
 *
 * @author netelixir
 */
@RestController
@RequestMapping("/user")
public class HeaderMappingController {

    @Autowired
    HeaderMappingService headerMappingService;

    @PostMapping(value = "/saveHeaders")
    public HeaderMappingDetails saveHeaders(@RequestBody HeaderMappingDetails headerMappingDetails,HttpSession session) throws Exception {
Jedis jedis = new Jedis("127.0.0.1", 6379);
Integer clientId = Integer.parseInt(jedis.get("emailClientId"));
        boolean isSuccess = headerMappingService.saveHeaders(headerMappingDetails, clientId);        
         String fileName = (String) jedis.get("fileName");
        headerMappingService.saveReportData(fileName,clientId);
        return headerMappingDetails;
    }
}
