/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.netelixir.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author netelixir
 */
@Entity
@Table(name = "ne_email_stats")
public class EmailReportStats implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "S_NO")
    private int sNo;

    @Column(name = "CLIENT_ID")
    private int clientId;

    @Column(name = "IMPRESSIONS")
    private int impressions;

    @Column(name = "CLICKS")
    private int clicks;

    @Column(name = "COST")
    private float cost;

    @Column(name = "REVENUE")
    private float revenue;

    @Column(name = "ORDERS")
    private float orders;

    @Column(name = "CPO")
    private float CPO;

    @Column(name = "CPC")
    private float CPC;

    @Column(name = "RbyC")
    private float RbyC;

    @Column(name = "AOV")
    private float AOV;

    @Column(name = "CTR")
    private float CTR;

    @Column(name = "SESSIONS")
    private int Sessions;

    @Column(name = "ROAS")
    private float ROAS;

    @Column(name = "CVR")
    private float CVR;

    @Column(name = "BUDGET")
    private float BUDGET;

    @Column(name = "NEW_SESSION_PERCENTAGE")
    private float newSessionPercentage;

    @Column(name = "GEO_LOCATION")
    private String Geo_Location;

    @Column(name = "COUNTRY")
    private String country;

    @Column(name = "DATE")
    private String date;

    transient protected String cpc;

    transient protected String cvr;

    transient protected String aov;

    transient protected String rev;

    transient protected String rbyc;

    transient protected String ctr;

    transient protected String spend;

    transient protected String session;

    transient protected String budget;

    transient protected String newSessionPer;

    transient protected String cpo;

    public float getBUDGET() {
        return BUDGET;
    }

    public void setBUDGET(float BUDGET) {
        this.BUDGET = BUDGET;
    }

    public float getNewSessionPercentage() {
        return newSessionPercentage;
    }

    public void setNewSessionPercentage(float newSessionPercentage) {
        this.newSessionPercentage = newSessionPercentage;
    }

    public int getsNo() {
        return sNo;
    }

    public void setsNo(int sNo) {
        this.sNo = sNo;
    }

    public int getClientId() {
        return clientId;
    }

    public void setClientId(int clientId) {
        this.clientId = clientId;
    }

    public int getimpressions() {
        return impressions;
    }

    public void setimpressions(int impressions) {
        this.impressions = impressions;
    }

    public int getClicks() {
        return clicks;
    }

    public void setClicks(int clicks) {
        this.clicks = clicks;
    }

    public float getCost() {
        return cost;
    }

    public void setCost(float cost) {
        this.cost = cost;
    }

    public float getRevenue() {
        return revenue;
    }

    public void setRev(String rev) {
        if (String.valueOf(rev).isEmpty() || "".equals(rev)) {
            setRevenue(Float.parseFloat("0.00"));
        } else if (String.valueOf(rev).contains(",") || String.valueOf(rev).contains("$") || String.valueOf(rev).contains("%")) {
            String str = rev.replace(",", "").replace("$", "").replace("%", "");
            setRevenue(Float.parseFloat(str));
        } else {
            setRevenue(Float.parseFloat(rev));
        }
    }

    public void setSpend(String spend) {
        if (String.valueOf(spend).isEmpty() || "".equals(spend)) {
            setCost(Float.parseFloat("0.00"));
        } else if (String.valueOf(spend).contains(",") || String.valueOf(spend).contains("$") || String.valueOf(spend).contains("%")) {
            String str = spend.replace(",", "").replace("$", "").replace("%", "");
            setCost(Float.parseFloat(str));
        } else {
            setCost(Float.parseFloat(spend));
        }
    }

    public void setcpo(String cpo) {
        if (String.valueOf(cpo).isEmpty() || "".equals(cpo)) {
            setCPO(Float.parseFloat("0.00"));
        } else if (String.valueOf(cpo).contains(",") || String.valueOf(cpo).contains("$") || String.valueOf(cpo).contains("%")) {
            String str = cpo.replace(",", "").replace("$", "").replace("%", "");
            setCPO(Float.parseFloat(str));
        } else {
            setCPO(Float.parseFloat(cpo));
        }
    }

    public void setRevenue(float revenue) {
        this.revenue = revenue;
    }

    public float getOrders() {
        return orders;
    }

    public void setOrders(float orders) {
        this.orders = orders;
    }

    public float getCPO() {
        return CPO;
    }

    public void setCPO(float CPO) {
        this.CPO = CPO;
    }

    public float getCPC() {
        return CPC;
    }

    public void setcpc(String cpc) {
        if (String.valueOf(cpc).isEmpty() || "".equals(cpc)) {
            setCPC(Float.parseFloat("0.00"));
        } else if (String.valueOf(cpc).contains(",") || String.valueOf(cpc).contains("%") || String.valueOf(cpc).contains("$")) {
            String str = cpc.replace(",", "").replace("%", "").replace("$", "");
            setCPC(Float.parseFloat(str));
        } else {
            setCPC(Float.parseFloat(cpc));
        }
    }

    public void setCPC(float CPC) {
        this.CPC = CPC;
    }

    public float getRbyC() {
        return RbyC;
    }

    public void setrbyc(String rbyc) {
        if (String.valueOf(rbyc).isEmpty() || "".equals(rbyc)) {
            setRbyC(Float.parseFloat("0.00"));
        } else if (String.valueOf(rbyc).contains(",") || String.valueOf(rbyc).contains("%") || String.valueOf(rbyc).contains("$")) {
            String str = rbyc.replace(",", "").replace("%", "").replace("$", "");
            setRbyC(Float.parseFloat(str));
        } else {
            setRbyC(Float.parseFloat(rbyc));
        }
    }

    public void setRbyC(float RbyC) {
        this.RbyC = RbyC;
    }

    public float getAOV() {
        return AOV;
    }

    public void setaov(String aov) {
        if (String.valueOf(aov).isEmpty() || "".equals(aov)) {
            setAOV(Float.parseFloat("0.00"));
        } else if (String.valueOf(aov).contains(",") || String.valueOf(aov).contains("%") || String.valueOf(aov).contains("$")) {
            String str = aov.replace(",", "").replace("%", "").replace("$", "");
            setAOV(Float.parseFloat(str));
        } else {
            setAOV(Float.parseFloat(aov));
        }
    }

    public void setAOV(float AOV) {
        this.AOV = AOV;
    }

    public float getCTR() {
        return CTR;
    }

    public void setctr(String ctr) {
        if (String.valueOf(ctr).isEmpty() || "".equals(ctr)) {
            setCTR(Float.parseFloat("0.00"));
        } else if (String.valueOf(ctr).contains(",") || String.valueOf(ctr).contains("%") || String.valueOf(ctr).contains("$")) {
            String str = ctr.replace(",", "").replace("%", "").replace("$", "");
            setCTR(Float.parseFloat(str));
        } else {
            setCTR(Float.parseFloat(ctr));
        }
    }

    public void setCTR(float CTR) {
        this.CTR = CTR;
    }

    public String getNewSessionPer() {
        return newSessionPer;
    }

    public void setNewSessionPer(String newSessionPer) {
        if (String.valueOf(newSessionPer).contains(",") || String.valueOf(newSessionPer).contains("%") || String.valueOf(newSessionPer).contains("$")) {
            String str = newSessionPer.replace(",", "").replace("%", "").replace("$", "");
            setNewSessionPercentage(Float.parseFloat(str));
        } else {
            setNewSessionPercentage(Float.parseFloat(newSessionPer));
        }
    }

    public int getSessions() {
        return Sessions;
    }

    public void setSessions(int Sessions) {
        this.Sessions = Sessions;
    }

    public float getROAS() {
        return ROAS;
    }

    public void setROAS(float ROAS) {
        this.ROAS = ROAS;
    }

    public float getCVR() {
        return CVR;
    }

    public void setcvr(String cvr) {
        if (String.valueOf(cvr).isEmpty() || "".equals(cvr)) {
            setCVR(Float.parseFloat("0.00"));
        } else if (String.valueOf(cvr).contains(",") || String.valueOf(cvr).contains("%") || String.valueOf(cvr).contains("$")) {
            String str = cvr.replace(",", "").replace("%", "").replace("$", "");
            setCVR(Float.parseFloat(str));
        } else {
            setCVR(Float.parseFloat(cvr));
        }
    }

    public void setCVR(float CVR) {
        this.CVR = CVR;
    }

    public String getGeo_Location() {
        return Geo_Location;
    }

    public void setGeo_Location(String Geo_Location) {
        this.Geo_Location = Geo_Location;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getSession() {
        return session;
    }

    public void setSession(String session) {
        if (String.valueOf(session).contains(",") || String.valueOf(session).contains("--") || String.valueOf(session).contains("%")) {
            String str = session.replace(",", "").replace("--", "").replace("%", "").replace("$", "").replace("/day", "");
            setSessions(Integer.parseInt(str));
        } else {
            setSessions(Integer.parseInt(session));
        }
    }

    public String getBudget() {
        return budget;
    }

    public void setBudget(String budget) {
        if (String.valueOf(budget).contains(",") || String.valueOf(budget).contains("--") || String.valueOf(budget).contains("$")) {
            String str = budget.replace(",", "").replace("--", "").replace("$", "").replace("/day", "");
            setBUDGET(Float.parseFloat(str));
        } else {
            setBUDGET(Float.parseFloat(budget));
        }
    }

}
