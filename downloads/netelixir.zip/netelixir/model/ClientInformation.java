/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.netelixir.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 *
 * @author netelixir
 */
@Entity
@Table(name = "ne_client_details")
public class ClientInformation implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @SequenceGenerator(name="ne_client_details_client_id_seq", sequenceName="ne_client_details_client_id_seq", allocationSize=1)
    @Column(name = "client_id")
    private int clientID;

    @Column(name = "clientname")
    private String clientName;

    @Column(name = "email_id")
    private String emailID;

    @Column(name = "subject")
    private String subject;

    @Column(name = "website")
    private String website;

    @Column(name = "company")
    private String company;

    @Column(name = "user_id")
    private int userID;

    @Column(name = "KPI")
    private String kpi;

    @Column(name = "KPI_CONDITION")
    private Byte kpiCondition;

    @Column(name = "KPI_VALUE")
    private float kpiValue;

    @Column(name = "enabled")
    private Byte enabled;

    @Column(name = "access_token")
    private String accessToken;

    @Column(name = "refresh_token")
    private String refreshToken;
    
    @Column(name="attachment_id")
    private String attachmentId;
    
    @Column(name="attachment_status")
    private Byte attachmentStatus;
    
    @Column(name = "password")
    private String password;

    public int getClientID() {
        return clientID;
    }

    public void setClientID(int clientID) {
        this.clientID = clientID;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getEmailID() {
        return emailID;
    }

    public void setEmailID(String emailID) {
        this.emailID = emailID;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public int getuserID() {
        return userID;
    }

    public void setuserID(int userID) {
        this.userID = userID;
    }

    public String getKpi() {
        return kpi;
    }

    public void setKpi(String kpi) {
        this.kpi = kpi;
    }

    public Byte getKpiCondition() {
        return kpiCondition;
    }

    public void setKpiCondition(Byte kpiCondition) {
        this.kpiCondition = kpiCondition;
    }

    public float getKpiValue() {
        return kpiValue;
    }

    public void setKpiValue(float kpiValue) {
        this.kpiValue = kpiValue;
    }

    public Byte getEnabled() {
        return enabled;
    }

    public void setEnabled(Byte enabled) {
        this.enabled = enabled;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getRefreshToken() {
        return refreshToken;
    }

    public void setRefreshToken(String refreshToken) {
        this.refreshToken = refreshToken;
    }

    public String getAttachmentId() {
        return attachmentId;
    }

    public void setAttachmentId(String attachmentId) {
        this.attachmentId = attachmentId;
    }

    public Byte getAttachmentStatus() {
        return attachmentStatus;
    }

    public void setAttachmentStatus(Byte attachmentStatus) {
        this.attachmentStatus = attachmentStatus;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    
}
