/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.netelixir.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author netelixir
 */
@Entity
@Table(name = "ne_header_mapping")
public class HeaderMappingInfo implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "S_NO")
    private int sNo;
    
    @Column(name = "CLIENT_ID")
    private int clientId;
    
    @Column(name = "VARIABLE_ID")
    private int varId;
    
    @Column(name = "VARIABLE_NAME")
    private String varName;
    
    @Column(name = "CLIENT_VARIABLE_NAME")
    private String clientVarName;

    public int getsNo() {
        return sNo;
    }

    public void setsNo(int sNo) {
        this.sNo = sNo;
    }

    public int getClientId() {
        return clientId;
    }

    public void setClientId(int clientId) {
        this.clientId = clientId;
    }

    public int getVarId() {
        return varId;
    }

    public void setVarId(int varId) {
        this.varId = varId;
    }

    public String getVarName() {
        return varName;
    }

    public void setVarName(String varName) {
        this.varName = varName;
    }

    public String getClientVarName() {
        return clientVarName;
    }

    public void setClientVarName(String clientVarName) {
        this.clientVarName = clientVarName;
    }
    
}
