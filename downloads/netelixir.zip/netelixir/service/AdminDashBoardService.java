/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.netelixir.service;

import com.netelixir.dao.EmailStatsDao;
import com.netelixir.model.EmailReportStats;
import com.netelixir.repository.EmailReportsRepository;
import com.netelixir.util.Query;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author netelixir
 */
@Service
public class AdminDashBoardService {

    @Autowired
    EmailStatsDao emailStatsDao;

    public Map<String, List<String>> getLastSevenDaysData(String fromDate, String toDate, int clientId) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yy");
        Query query = new Query();
        String sqlQuery = query.getLastSevenDaysData(fromDate, toDate, clientId);
        List<EmailReportStats> emailReports = emailStatsDao.getLastSevenDaysData(sqlQuery);

        Map<String, List<String>> emailReportsMap = new LinkedHashMap<>();
        if(!emailReports.isEmpty()){
         List<String> revenue = new ArrayList<>();
         List<String> orders = new ArrayList<>();
         List<String> impressions = new ArrayList<>();
         List<String> clicks = new ArrayList<>();
//         String orders="";
//         String impressions="";
//         String clicks="";
        for (int i = 0; i < emailReports.size(); i++) {
//            if (revenue == "") {
//                revenue = String.valueOf(emailReports.get(i).getRevenue()) ;
//            } else {
//                revenue = revenue + "," + String.valueOf(emailReports.get(i).getRevenue());
//            }            
//            if (orders == "") {
//                orders = String.valueOf(emailReports.get(i).getOrders()) ;
//            } else {
//                orders = orders + ","+ String.valueOf(emailReports.get(i).getOrders());
//            }            
//            if (impressions == "") {
//                impressions = String.valueOf(emailReports.get(i).getimpressions()) ;
//            } else {
//                impressions = impressions + ","+ String.valueOf(emailReports.get(i).getimpressions());
//            }            
//            if (clicks == "") {
//                clicks = String.valueOf(emailReports.get(i).getClicks()) ;
//            } else {
//                clicks = clicks + ","+ String.valueOf(emailReports.get(i).getClicks());
//            }   
                revenue.add(String.valueOf(emailReports.get(i).getRevenue()));
                orders.add(String.valueOf(emailReports.get(i).getOrders()));
                impressions.add(String.valueOf(emailReports.get(i).getimpressions()));
                clicks.add(String.valueOf(emailReports.get(i).getClicks()));
        }
        emailReportsMap.put("revenue", revenue);        
        emailReportsMap.put("orders", orders);        
        emailReportsMap.put("impressions", impressions);        
        emailReportsMap.put("clicks", clicks);        
        
        }
       
        return emailReportsMap;

    }

}
