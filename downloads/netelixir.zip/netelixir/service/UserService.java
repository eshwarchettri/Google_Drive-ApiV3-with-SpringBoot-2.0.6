package com.netelixir.service;

import java.util.Set;

import com.netelixir.domain.User;
import com.netelixir.domain.security.UserRole;
import java.util.List;

public interface UserService {
	
        
        User createUser(User user, Set<UserRole> userRoles);
        
        User findByUsername(String username);
	
	User findByEmail (String email);
	
	User save(User user);
	
	User findById(Long id);
        
        List<User> findAll();
        
        

}
