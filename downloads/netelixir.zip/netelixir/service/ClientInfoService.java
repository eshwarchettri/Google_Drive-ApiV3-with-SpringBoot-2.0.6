/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.netelixir.service;

import com.google.api.client.auth.oauth2.TokenResponse;
import com.netelixir.repository.ClientInformationRepository;
import com.netelixir.model.ClientHomePage;
import com.netelixir.model.ClientHomePage;
import com.netelixir.model.ClientInformation;
import com.netelixir.model.ClientInformation;
import java.util.List;
import java.util.stream.Collectors;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author netelixir
 */
@Service
public class ClientInfoService {
    
    private static final Log LOGGER = LogFactory.getLog(ClientInfoService.class);
    
    @Autowired
    ClientInformationRepository clientInformationDao;
    
    public ClientInformation saveNewClientInfo(ClientHomePage clientInfo, int user_id) {
        
        ClientInformation updatedClientInfo = null;
        try {
            ClientInformation clientInformation = new ClientInformation();
            clientInformation.setClientName(clientInfo.getClientName());
            clientInformation.setEmailID(clientInfo.getEmailid());
            clientInformation.setSubject(clientInfo.getSubject());
            clientInformation.setPassword(clientInfo.getPassword());
//            clientInformation.setCompany(clientInfo.getCompany());
//            clientInformation.setWebsite(clientInfo.getWebsite());
            clientInformation.setuserID(user_id);
//            clientInformation.setKpi(clientInfo.getKpi());
//            clientInformation.setKpiValue(clientInfo.getKpiValue());
            clientInformation.setEnabled((byte) 1);//Default Enabled - 1
//            clientInformation.setKpiCondition(clientInfo.getKpiCondition());
//            clientInformation.setAccessToken(clientInfo.getAccessToken());
//            clientInformation.setRefreshToken(clientInfo.getRefreshToken());
            clientInformation.setAttachmentId("");
            updatedClientInfo = clientInformationDao.save(clientInformation);
        } catch (Exception e) {
            LOGGER.error("Exception in updating clientInfo for Client " + clientInfo.getClientName(), e);
        }
        return updatedClientInfo;
    }
    public List<ClientInformation> findAll(){    
    return clientInformationDao.findAll().stream().filter(e-> e.getEnabled() !=0 ).collect(Collectors.toList());
    }
    public void saveTokens(TokenResponse response, int clientId) {
        try {
             ClientInformation updatedClientInfo =clientInformationDao.findById(clientId).orElse(null) ;
             updatedClientInfo.setRefreshToken(response.getRefreshToken());
             updatedClientInfo.setAccessToken(response.getAccessToken());
            clientInformationDao.save(updatedClientInfo);
        } catch (Exception e) {
            LOGGER.error("Exception in updating tokens for Client: " + clientId, e);
        }
    }

    public void disableClient(int clientId) {
        try {
             ClientInformation updatedClientInfo =clientInformationDao.findById(clientId).orElse(null) ;
             updatedClientInfo.setEnabled((byte)0);
            clientInformationDao.save(updatedClientInfo);
        } catch (Exception e) {
            LOGGER.error("Exception in updating tokens for Client: " + clientId, e);
        }
        
    }
}

