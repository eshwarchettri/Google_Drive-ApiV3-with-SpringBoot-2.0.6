/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.netelixir.service;

import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeFlow;
import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets;
import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.client.repackaged.org.apache.commons.codec.binary.Base64;
import com.google.api.services.gmail.model.ListMessagesResponse;
import com.google.api.services.gmail.model.Message;
import com.google.api.services.gmail.model.MessagePart;
import com.google.api.services.gmail.model.MessagePartBody;
import com.opencsv.CSVReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpSession;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import com.netelixir.repository.ClientInformationRepository;
import com.netelixir.model.ClientInformation;
import java.security.GeneralSecurityException;
import javax.servlet.http.HttpServletRequest;
import redis.clients.jedis.Jedis;
//import javax.ws.rs.core.Context;

/**
 *
 * @author netelixir
 */
@Service
public class GmailService {

    private static final Log LOGGER = LogFactory.getLog(GmailService.class);
    @Value("${gmail.client.clientId}")
    private String CLIENT_ID;

    @Value("${gmail.client.redirectUri}")
    private String REDIRECT_URI;

    @Value("${gmail.client.clientSecret}")
    private String CLIENT_SECRET;

    @Value("${files.path}")
    private String filePath;

    private static final String APPLICATION_NAME = "Email Reports";
    private static HttpTransport httpTransport;
    private static final JsonFactory JSON_FACTORY = JacksonFactory.getDefaultInstance();
    private static com.google.api.services.gmail.Gmail client;
    GoogleClientSecrets clientSecrets;
    GoogleAuthorizationCodeFlow flow;
    Credential credential;

    @Autowired
    EmailReportsService emailReportsService;

    @Autowired
    ClientInformationRepository clientInformationDao;

//    @Context
//    private HttpServletRequest request;
    @Autowired
    HeaderMappingService headerMappingService;

    public void emailreports() {
        List<ClientInformation> clientInformation = clientInformationDao.findAll();
        for (int i = 0; i < clientInformation.size(); i++) {
            credential = getCredentials(clientInformation.get(i));
            HttpSession session = null;

            ListMessagesResponse msgResponse = getGmailMessage(credential, 11);
            if(!msgResponse.isEmpty()){
           readMessgeAndProcess(session, msgResponse, true, 11);
            }
        }

    }

    public Credential getCredentials(ClientInformation clientInformation) {
        try {
            httpTransport = GoogleNetHttpTransport.newTrustedTransport();
            credential = new GoogleCredential.Builder().
                    setTransport(httpTransport)
                    .setJsonFactory(JSON_FACTORY)
                    .setClientSecrets(CLIENT_ID, CLIENT_SECRET).build();
            credential.setAccessToken(clientInformation.getAccessToken());
            credential.setRefreshToken(clientInformation.getRefreshToken());

        } catch (GeneralSecurityException ex) {
            Logger.getLogger(GmailService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(GmailService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return credential;
    }

//    public Map<String, ArrayList<String>> readMessgeAndProcess(HttpSession session, ListMessagesResponse MsgResponse, boolean isScheduler, int clientId) {
    public String[] readMessgeAndProcess(HttpSession session, ListMessagesResponse MsgResponse, boolean isScheduler, int clientId) {
        String userId = "me";
        String file = "";
        boolean isBreak = false;
                    Jedis jedis = new Jedis("127.0.0.1", 6379);

        String[] header=new String[50];
//        ArrayList<String> headerMapper = new ArrayList<>();
        Map<String, ArrayList<String>> headerColumns = new LinkedHashMap<>();
        for (Message msg : MsgResponse.getMessages()) {

            try {
                //                messages.add(msg);
                Message message = client.users().messages().get(userId, msg.getId()).execute();
                List<MessagePart> parts = message.getPayload().getParts();

                for (MessagePart part : parts) {
                    if (part.getFilename() != null && part.getFilename().length() > 0) {
                        String filename = part.getFilename();
                        String attId = part.getBody().getAttachmentId();
                        MessagePartBody attachments = client.users().messages().attachments().get(userId, msg.getId(), attId).execute();
                        System.out.println("message id :" + msg.getId());
                        file = filePath + filename;
                        Base64 base64Url = new Base64(true);
                        byte[] fileByteArray = base64Url.decodeBase64(attachments.getData());
                        FileOutputStream fileOutFile = new FileOutputStream(file);
                        fileOutFile.write(fileByteArray);
                        fileOutFile.close();
                        ClientInformation clientInformation = clientInformationDao.findById(clientId).orElse(null);
                        if (!clientInformation.getAttachmentId().replace("<", "").replace(">", "").trim().equalsIgnoreCase(part.getHeaders().get(3).getValue())) {
                           
                            clientInformation.setAttachmentId( part.getHeaders().get(3).getValue());
                            clientInformation.setAttachmentStatus((byte)0);
                            clientInformationDao.save(clientInformation);
                            if (isScheduler) {
                                headerMappingService.saveReportData(file, clientId);
                            } else {
                                CSVReader reader = new CSVReader(new FileReader(file));
                                // if the first line is the header
                                header = reader.readNext();
//                                headerColumns = emailReportsService.getAllHeaders(header);
                                session.setAttribute("fileName", file);
                                jedis.set("fileName", file);

                            }

                        }

                    }
                    if (!part.getFilename().isEmpty()) {
                        isBreak = true;
                        break;
                    }
                }
                if (isBreak) {
                    break;
                }
            } catch (IOException ex) {
                Logger.getLogger(GmailService.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return header;
    }

    public ListMessagesResponse getGmailMessage(Credential credential, int clientId) {
        ListMessagesResponse MsgResponse = new ListMessagesResponse();
        ClientInformation clientInformation = clientInformationDao.findById(clientId).orElse(null);
        try {
            httpTransport = GoogleNetHttpTransport.newTrustedTransport();
            client = new com.google.api.services.gmail.Gmail.Builder(httpTransport, JSON_FACTORY, credential)
                    .setApplicationName(APPLICATION_NAME).build();
            String query = "subject:'(" + clientInformation.getSubject() + ")'";
            MsgResponse = client.users().messages().list("me").setQ(query).execute();

        } catch (IOException | GeneralSecurityException ex) {
            Logger.getLogger(GmailService.class.getName()).log(Level.SEVERE, "for client Id: " + clientId, ex);
        }
        return MsgResponse;
    }
}
