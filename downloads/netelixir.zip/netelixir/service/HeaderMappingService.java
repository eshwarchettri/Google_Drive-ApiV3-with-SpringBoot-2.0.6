/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.netelixir.service;

import com.netelixir.dao.EmailStatsDao;
import com.netelixir.repository.ClientInformationRepository;
import com.netelixir.repository.EmailReportsRepository;
import com.netelixir.repository.HeaderMappingRepository;
import com.netelixir.model.ClientInformation;
import com.netelixir.model.EmailReportStats;
import com.netelixir.model.HeaderMappingDetails;
import com.netelixir.model.HeaderMappingInfo;
import com.netelixir.util.CSVbeanMappingColumn;
import com.opencsv.CSVReader;
import com.opencsv.bean.CsvToBean;
//import com.opencsv.bean.CsvToBeanBuilder;
import com.opencsv.bean.HeaderColumnNameTranslateMappingStrategy;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author netelixir
 */
@Service
public class HeaderMappingService {
    
    private static final Log LOGGER = LogFactory.getLog(HeaderMappingService.class);
    @Autowired
    HeaderMappingRepository mappingRepository;
    
    @Autowired
    EmailStatsDao emailStatsDao;
    
    
    @Autowired
    ClientInformationRepository informationRepository;
    
    public boolean saveHeaders(HeaderMappingDetails headerMappingDetails, int clientId) {
        boolean isSucess = false;
        
        Map<String, String> mappedHeaders = new HashMap<>();
        mappedHeaders.put("aov", headerMappingDetails.getAov());
        mappedHeaders.put("cpc", headerMappingDetails.getCpc());
        mappedHeaders.put("cpo", headerMappingDetails.getCpo());
        mappedHeaders.put("ctr", headerMappingDetails.getCtr());
        mappedHeaders.put("cvr", headerMappingDetails.getCvr());
        mappedHeaders.put("clicks", headerMappingDetails.getClicks());
        mappedHeaders.put("country", headerMappingDetails.getCountry());
        mappedHeaders.put("geo_location", headerMappingDetails.getGeo_location());
        mappedHeaders.put("impressions", headerMappingDetails.getImpressions());
        mappedHeaders.put("orders", headerMappingDetails.getOrders());
        mappedHeaders.put("roas", headerMappingDetails.getRoas());
        mappedHeaders.put("rbyc", headerMappingDetails.getRbyc());
        mappedHeaders.put("rev", headerMappingDetails.getRevenue());
        mappedHeaders.put("session", headerMappingDetails.getSession());
        mappedHeaders.put("date", headerMappingDetails.getDate());
        mappedHeaders.put("spend", headerMappingDetails.getCost());
        mappedHeaders.put("budget", headerMappingDetails.getBudget());
        mappedHeaders.put("newSessionPercentage", headerMappingDetails.getNewSessionPercentage());

//        isSucess = headerMappingDao.saveHeaders(mappedHeaders,clientId);
        for (Map.Entry<String, String> entry : mappedHeaders.entrySet()) {
            HeaderMappingInfo mheaders = new HeaderMappingInfo();
            if (entry.getKey().equalsIgnoreCase("impressions")) {
                mheaders.setClientVarName(entry.getValue());
                mheaders.setVarName("impressions");
                mheaders.setVarId(1);
                mheaders.setClientId(clientId);
            } else if (entry.getKey().equalsIgnoreCase("clicks")) {
                mheaders.setClientVarName(entry.getValue());
                mheaders.setVarName("clicks");
                mheaders.setVarId(2);
                mheaders.setClientId(clientId);
            } else if (entry.getKey().equalsIgnoreCase("rev")) {
                mheaders.setClientVarName(entry.getValue());
                mheaders.setVarName("rev");
                mheaders.setVarId(3);
                mheaders.setClientId(clientId);
            } else if (entry.getKey().equalsIgnoreCase("orders")) {
                mheaders.setClientVarName(entry.getValue());
                mheaders.setVarName("orders");
                mheaders.setVarId(4);
                mheaders.setClientId(clientId);
            } else if (entry.getKey().equalsIgnoreCase("cpo")) {
                mheaders.setClientVarName(entry.getValue());
                mheaders.setVarName("cpo");
                mheaders.setVarId(5);
                mheaders.setClientId(clientId);
            } else if (entry.getKey().equalsIgnoreCase("cpc")) {
                mheaders.setClientVarName(entry.getValue());
                mheaders.setVarName("cpc");
                mheaders.setVarId(6);
                mheaders.setClientId(clientId);
            } else if (entry.getKey().equalsIgnoreCase("rbyc")) {
                mheaders.setClientVarName(entry.getValue());
                mheaders.setVarName("rbyc");
                mheaders.setVarId(7);
                mheaders.setClientId(clientId);
            } else if (entry.getKey().equalsIgnoreCase("aov")) {
                mheaders.setClientVarName(entry.getValue());
                mheaders.setVarName("aov");
                mheaders.setVarId(8);
                mheaders.setClientId(clientId);
            } else if (entry.getKey().equalsIgnoreCase("ctr")) {
                mheaders.setClientVarName(entry.getValue());
                mheaders.setVarName("ctr");
                mheaders.setVarId(9);
                mheaders.setClientId(clientId);
            } else if (entry.getKey().equalsIgnoreCase("session")) {
                mheaders.setClientVarName(entry.getValue());
                mheaders.setVarName("session");
                mheaders.setVarId(10);
                mheaders.setClientId(clientId);
            } else if (entry.getKey().equalsIgnoreCase("roas")) {
                mheaders.setClientVarName(entry.getValue());
                mheaders.setVarName("roas");
                mheaders.setVarId(11);
                mheaders.setClientId(clientId);
            } else if (entry.getKey().equalsIgnoreCase("cvr")) {
                mheaders.setClientVarName(entry.getValue());
                mheaders.setVarName("cvr");
                mheaders.setVarId(12);
                mheaders.setClientId(clientId);
            } else if (entry.getKey().equalsIgnoreCase("geo_location")) {
                mheaders.setClientVarName(entry.getValue());
                mheaders.setVarName("geo_location");
                mheaders.setVarId(13);
                mheaders.setClientId(clientId);
            } else if (entry.getKey().equalsIgnoreCase("country")) {
                mheaders.setClientVarName(entry.getValue());
                mheaders.setVarName("country");
                mheaders.setVarId(14);
                mheaders.setClientId(clientId);
            } else if (entry.getKey().equalsIgnoreCase("date")) {
                mheaders.setClientVarName(entry.getValue());
                mheaders.setVarName("date");
                mheaders.setVarId(15);
                mheaders.setClientId(clientId);
            }else if (entry.getKey().equalsIgnoreCase("budget")) {
                mheaders.setClientVarName(entry.getValue());
                mheaders.setVarName("budget");
                mheaders.setVarId(16);
                mheaders.setClientId(clientId);
            }else if (entry.getKey().equalsIgnoreCase("newSessionPercentage")) {
                mheaders.setClientVarName(entry.getValue());
                mheaders.setVarName("newSessionPercentage");
                mheaders.setVarId(17);
                mheaders.setClientId(clientId);
            }else if (entry.getKey().equalsIgnoreCase("spend")) {
                mheaders.setClientVarName(entry.getValue());
                mheaders.setVarName("spend");
                mheaders.setVarId(18);
                mheaders.setClientId(clientId);
            }
            mappingRepository.save(mheaders);
            isSucess=true;
        }
        
        return isSucess;
        
    }
    
    public void saveReportData(String fileName, int clientId) {
        try {
            List<HeaderMappingInfo> csvHeaders = mappingRepository.findByclientId(clientId).stream().filter(e -> e.getClientVarName() !=null).collect(Collectors.toList());
            List<EmailReportStats> emailReportStats = new ArrayList<>();
            HeaderColumnNameTranslateMappingStrategy<EmailReportStats> emailReportStatergy = new HeaderColumnNameTranslateMappingStrategy<>();
            emailReportStatergy.setType(EmailReportStats.class);
            emailReportStatergy.setColumnMapping(CSVbeanMappingColumn.getSavedColNamesMap(csvHeaders));
            CsvToBean<EmailReportStats> csvToBean = new CsvToBean<>();
            CSVReader reader = new CSVReader(new FileReader(fileName));
            LOGGER.info("parsing of csv to Bean Started....");
            emailReportStats = csvToBean.parse(emailReportStatergy, reader);
            boolean isSuccess=false;
            try {
                emailReportStats.stream().forEach(data -> {
                    EmailReportStats reportStats = data;
                    reportStats.setClientId(clientId);
                    emailStatsDao.save(reportStats);
                });
                isSuccess=true;
            } catch (Exception e) {
                LOGGER.error(e);
            }
            
//            boolean isSuccess = headerMappingDaoImpl.saveCSVReportData(emailReportStats, clientId);
          ClientInformation clientInformation = informationRepository.findById(clientId).orElse(null);           
            if (isSuccess) {
                clientInformation.setAttachmentStatus((byte) 1);
                informationRepository.save(clientInformation);
            } else {
                clientInformation.setAttachmentId("");
                clientInformation.setAttachmentStatus((byte) 0);
                informationRepository.save(clientInformation);
            }
            LOGGER.info("parsing of csv to Bean Ended....");
        } catch (FileNotFoundException ex) {
            LOGGER.error("Exception is due to : " + ex);
        }
    }
    
}
