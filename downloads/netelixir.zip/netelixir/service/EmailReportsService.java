/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.netelixir.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;
import org.springframework.stereotype.Service;

/**
 *
 * @author netelixir
 */
@Service
public class EmailReportsService {

 
    public Map<String, ArrayList<String>> getAllHeaders(String[] header) {
        Map<String, ArrayList<String>> columnHeadersMap = new LinkedHashMap<>();
        ArrayList<String> headers = new ArrayList<>(Arrays.asList(header));
        ArrayList<String> sortedHeaders = new ArrayList<>();
        sortedHeaders.addAll(headers.stream().sorted((o1, o2) -> o1.compareTo(o2)).collect(Collectors.toList()));
        columnHeadersMap.put("impressions", sortedHeaders);
        columnHeadersMap.put("clicks", sortedHeaders);
        columnHeadersMap.put("revenue", sortedHeaders);
        columnHeadersMap.put("orders", sortedHeaders);
        columnHeadersMap.put("cpc", sortedHeaders);
        columnHeadersMap.put("cpo", sortedHeaders);
        columnHeadersMap.put("rbyc", sortedHeaders);
        columnHeadersMap.put("aov", sortedHeaders);
        columnHeadersMap.put("ctr", sortedHeaders);
        columnHeadersMap.put("sessions", sortedHeaders);
        columnHeadersMap.put("roas", sortedHeaders);
        columnHeadersMap.put("cvr", sortedHeaders);
        columnHeadersMap.put("geo_location", sortedHeaders);
        columnHeadersMap.put("country", sortedHeaders);
        columnHeadersMap.put("date", sortedHeaders);
        return columnHeadersMap;
    }
}
