/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.netelixir.repository;

import com.netelixir.model.EmailReportStats;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

/**
 *
 * @author netelixir
 */
public interface EmailReportsRepository extends CrudRepository<EmailReportStats, Integer>{
List<EmailReportStats> findByclientId(int clientId);


}
