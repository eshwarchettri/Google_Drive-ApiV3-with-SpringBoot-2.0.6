package com.netelixir.repository;

import org.springframework.data.repository.CrudRepository;

import com.netelixir.domain.security.Role;

public interface RoleRepository extends CrudRepository<Role, Long> {

}
