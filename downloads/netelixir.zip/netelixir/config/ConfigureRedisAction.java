/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.netelixir.config;

import org.springframework.data.redis.connection.RedisConnection;

/**
 * Allows specifying a strategy for configuring and validating Redis.
 *
 * @author Rob Winch
 * @since 1.0.1
 */
public interface ConfigureRedisAction {

	void configure(RedisConnection connection);

	/**
	 * A do nothing implementation of {@link ConfigureRedisAction}.
	 */
	ConfigureRedisAction NO_OP = (connection) -> {
	};

}
