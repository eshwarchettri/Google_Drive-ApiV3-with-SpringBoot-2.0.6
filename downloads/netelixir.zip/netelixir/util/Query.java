/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.netelixir.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 *
 * @author netelixir
 */
public class Query {

    public String getLastSevenDaysData(String fromDate, String toDate, int clientId) {
        String oldDate = toDate;
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yy");
        Calendar c = Calendar.getInstance();
        try {
            c.setTime(sdf.parse(oldDate));
        } catch (ParseException e) {

        }
        c.add(Calendar.DAY_OF_MONTH, 1);
        String newDate = sdf.format(c.getTime());
        String sql = "select * from ne_email_stats where client_id=" + clientId + " and date between '" + fromDate + "'"
                + " and '" + toDate + "'";
//                + " UNION ALL (SELECT '" + fromDate + "' + INTERVAL a + b DAY AS date, 0 AS orders,0 AS revenue,"
//                + " 0 AS sessions  FROM  (SELECT 0 a UNION SELECT 1 a UNION SELECT 2 UNION SELECT 3 UNION SELECT"
//                + " 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) d,"
//                + " (SELECT 0 b UNION SELECT 10 UNION SELECT 20 UNION SELECT 30 UNION SELECT 40) "
//                + "m WHERE '" + fromDate + "' + INTERVAL a + b DAY < '" + newDate + "' ORDER BY a + b)";
        return sql;
    }
}
