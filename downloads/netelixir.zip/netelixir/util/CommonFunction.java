/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.netelixir.util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author netelixir
 */
public class CommonFunction {
    
      public String[] getDates(int i) {
        String[] dates = new String[2];
        LocalDate toDate = LocalDate.now();
        LocalDate fromDate = toDate.minusDays(i);
        dates[1] = toDate.minusDays(1).format(DateTimeFormatter.ofPattern("dd/MM/yy"));
        if (i == 370) {
            dates[0] = toDate.minusYears(1).withDayOfMonth(1).format(DateTimeFormatter.ofPattern("dd/MM/yy"));
        } else {
            dates[0] = fromDate.format(DateTimeFormatter.ofPattern("dd/MM/yy"));
        }
        return dates;
    }
}
