/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.netelixir.util;

import com.netelixir.model.HeaderMappingInfo;
import java.util.LinkedHashMap;
import java.util.List;

/**
 *
 * @author netelixir
 */
public class CSVbeanMappingColumn {

    private static final LinkedHashMap<String, String> columnMapping = new LinkedHashMap<>();
    public static LinkedHashMap<String, String> getSavedColNamesMap(List<HeaderMappingInfo> csvHeaders) {
        for (int i = 0; i < csvHeaders.size(); i++) {
            columnMapping.put(csvHeaders.get(i).getClientVarName(), csvHeaders.get(i).getVarName());

        }

        return columnMapping;
    }
}
